package com.miguelsportal.googleloginm;

import android.app.Activity;
import android.os.Bundle;


/**
 * Created by Miguel on 11/6/2016.
 * Description: This is the Maps class. A map implementation
 * is still in progress.....
 */

public class MapsActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
    }



}
