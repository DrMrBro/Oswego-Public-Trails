package com.miguelsportal.googleloginm;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Miguel on 11/6/2016.
 * Description: This is the Trails class. A trail's listing
 * implementation is in progress....
 */

public class TrailsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trails);
    }
}
