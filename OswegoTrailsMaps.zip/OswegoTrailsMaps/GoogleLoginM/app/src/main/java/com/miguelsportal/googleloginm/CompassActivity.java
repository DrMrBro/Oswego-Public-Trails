package com.miguelsportal.googleloginm;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Miguel on 11/6/2016.
 * Description: This the compass class that allows the
 *  users to use a compass.
 */

public class CompassActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compass);

    }
}
