package com.miguelsportal.googleloginm;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Miguel on 11/6/2016.
 * Description: This is the weather's class. A weather
 * interactive application implementation is in progress.....
 */

public class WeatherActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
    }
}
